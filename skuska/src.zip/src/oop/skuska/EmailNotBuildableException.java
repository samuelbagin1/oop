package oop.skuska;

public class EmailNotBuildableException extends Exception {
    public EmailNotBuildableException(String message) {
        super(message);
    }
}
